a=([1],2,3)

a[0].append(5)
print(a)

a=lambda x:x*2

print(a(2))
