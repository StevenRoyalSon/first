from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.registrationview, name='registrationview'),
    path('login/', views.loginview, name='loginview') ,
    path('logout.html/', views.logout,name='logout'),
path('register.html/', views.registrationview, name='registrationview'),
    path('login.html/', views.loginview, name='loginview') ,
    path('logout/', views.logout,name='logout'),
path('password.html/', views.forgot, name='forgot') ,
    path('password/', views.forgot,name='forgot'),

]
