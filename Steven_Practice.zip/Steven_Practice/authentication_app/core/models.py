from django.db import models

# Create your models here.
class user_details(models.Model):
    username=models.CharField()
    password=models.CharField()
    firstname=models.CharField()
    lastname=models.CharField()
    email=models.CharField()
    print(username,'====',password)

    def __str__(self):
        return self.username
