from django.shortcuts import render
from django.http import HttpResponse
from . import models
from .models import user_details

def home(request):
    return render(request,'index.html')

def registrationview(request):
    if request.method == 'POST':
        firstname = request.POST.get('first_name')
        lastname = request.POST.get('last_name')
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        # Save the user details to the database
        ud = user_details(
            firstname=firstname,
            lastname=lastname,
            username=username,
            email=email,
            password=password
        )
        print(email,'====')
        ud.save()  # Save the instance to the database

    return render(request, 'register.html')

def loginview(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        try:
            user = user_details.objects.get(username=username, password=password)
            if user:
                return HttpResponse('<center><h1>login succesfully</h1></center>')
            print(f"User found: {user.username}, {user.email}")
        except user_details.DoesNotExist:
            print("User not found or incorrect password")
            return HttpResponse('<h1>invalid credentials</h1>')

    return render(request, 'login.html')

def logout(request):
    return render(request,'logout.html')

def forgot(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        username=request.POST.get('username')
        try:
            user = user_details.objects.get(email=email,username=username)
            username = user.username
            password = user.password
            return HttpResponse(f'<h1>for username :- {username}</h1><br><h2>Password is:- {password}</h2>')
        except user_details.DoesNotExist:
            return HttpResponse('<h1>Invalid email</h1>')
    return render(request, 'password.html')