from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse

def signup(request):
    pass

def login(request):
    pass

def dashboard(request):
    pass

def logout(request):
    pass