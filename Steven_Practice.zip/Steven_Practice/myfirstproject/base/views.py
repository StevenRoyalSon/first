from django.shortcuts import render
from django.http import HttpResponse

rooms=[{'id':1,'name':'steven'},
       {'id':2,'name':'royal son'}]

def home(request):
    return render(request,'home.html',{'rooms':rooms})

def about(request):
    return render(request,'about.html')